function Get-Chassis {
    <#
    .SYNOPSIS
    Retrieves Chassis Types.
    .DESCRIPTION
    Pulls system closure information from win32_systemenclosure and will then convert into a numeric value for later configuration usage.
    .PARAMETER ComputerName
    The name or IP address of the computer we are retrieving the chassis type from. This is a mandatory value.
    .EXAMPLE
    $chassis = Get-Chassis -ComputerName SERVER1
    .EXAMPLE
    $chassis = Get-Chassis -ComputerName SERVER1 | Where-Object -Property SERVER1 -ne NULL
    #>
    
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline=$True, ValueFromPipelineByPropertyName=$True, Mandatory=$True, HelpMessage='Computer name or IP address')]
        [string[]]$ComputerName
    )

    BEGIN {}
    PROCESS {
        $chassis = Get-WmiObject -Class win32_systemenclosure -ComputerName $ComputerName | Select-Object -Property ChassisTypes
        if ($chassis.chassistypes -contains '3'){$unit = "3"}  #Desktop
        elseif ($chassis.chassistypes -contains '4'){$unit = "4"}  #Low Profile Desktop
        elseif ($chassis.chassistypes -contains '5'){$unit = "5"}  #Pizza Box
        elseif ($chassis.chassistypes -contains '6'){$unit = "6"}  #Mini Tower
        elseif ($chassis.chassistypes -contains '7'){$unit = "7"}  #Tower
        elseif ($chassis.chassistypes -contains '8'){$unit = "8"}  #Portable
        elseif ($chassis.chassistypes -contains '9'){$unit = "9"}  #Laptop
        elseif ($chassis.chassistypes -contains '10'){$unit = "10"}  #Notebook
        elseif ($chassis.chassistypes -contains '11'){$unit = "11"}  #Hand Held
        elseif ($chassis.chassistypes -contains '12'){$unit = "12"}  #Docking Station
        elseif ($chassis.chassistypes -contains '13'){$unit = "13"}  #All in One
        elseif ($chassis.chassistypes -contains '14'){$unit = "14"}  #Sub Notebook
        elseif ($chassis.chassistypes -contains '15'){$unit = "15"}  #Space-Saving
        elseif ($chassis.chassistypes -contains '16'){$unit = "16"}  #Lunch Box
        elseif ($chassis.chassistypes -contains '17'){$unit = "17"}  #Main System Chassis
        elseif ($chassis.chassistypes -contains '18'){$unit = "18"}  #Expansion Chassis
        elseif ($chassis.chassistypes -contains '19'){$unit = "19"}  #Sub Chassis
        elseif ($chassis.chassistypes -contains '20'){$unit = "20"}  #Bus Expansion Chassis
        elseif ($chassis.chassistypes -contains '21'){$unit = "21"}  #Peripheral Chassis
        elseif ($chassis.chassistypes -contains '22'){$unit = "22"}  #Storage Chassis
        elseif ($chassis.chassistypes -contains '23'){$unit = "23"}  #Rack Mount Chassis
        elseif ($chassis.chassistypes -contains '24'){$unit = "24"}  #Sealed-Case PC
        else {$unit = "Unknown"}  #Unknown
        return $unit
    }
    END {Write-Host "`n Chassis Type: $unit"}
}