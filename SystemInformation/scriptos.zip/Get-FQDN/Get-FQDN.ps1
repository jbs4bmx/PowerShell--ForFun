﻿#Requires -Version 2
<#
.SYNOPSIS
    <Overview of script goes here>
.DESCRIPTION
    <Brief description of script>
.PARAMETER <Parameter_1_Name>
    <Brief description of parameter input required. Repeat this attribute if required>
.INPUTS
    <Inputs if any, otherwise state None>
.OUTPUTS
    <Outputs if any, otherwise state None - example: Log file stored in C:\Windows\Temp\<name>.log>
    C:\Temp\setup.log
.NOTES
    Version:        | <n, n.n, n.n.n, etc.>
    Author:         | <your name here>
    Creation Date:  | <Date>
    Change Date:    | <Date of last Change(s)>
    Purpose/Change: | <Purpose of changes (editing, bug fix, etc.)>
    License:        | MIT (https://opensource.org/licenses/MIT)
      Copyright (c) <Year> <Owner>

      Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation
      files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy,
      modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
      Software is furnished to do so, subject to the following conditions:

      The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

      THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
      WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
      COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
      ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
.EXAMPLE
    <Example goes here. Repeat this attribute for more than one example>
#>

#------------------------------------------------------------[Elevation]-----------------------------------------------------------
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
if ($myWindowsPrincipal.IsInRole($adminRole)) {
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
    $Host.UI.RawUI.BackgroundColor = "DarkBlue"
    clear-host
} else {
    $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
    $newProcess.Arguments = $myInvocation.MyCommand.Definition;
    $newProcess.Arguments = $myInvocation.MyCommand.Path;
    $newProcess.Verb = "runas";
    [System.Diagnostics.Process]::Start($newProcess);
    exit
}

#--------------------------------------------------------[Initialisations]---------------------------------------------------------
#Set Error Action to Silently Continue
$ErrorActionPreference = "SilentlyContinue"

#----------------------------------------------------------[Declarations]----------------------------------------------------------
# Source File.

#

#-----------------------------------------------------------[Functions]------------------------------------------------------------
# None.

#-----------------------------------------------------------[Execution]------------------------------------------------------------
#<The rest of the script is executed here>
Clear-Host

#Start Time
ForEach ($computer in (Get-Content computers.txt)) {
    Try {
        [net.dns]::GetHostEntry($Computer).Hostname | Out-File -FilePath fullnames.txt -Append
    } Catch {
        $Computer | Out-File -FilePath fullnames.txt -Append
    }
}

exit
