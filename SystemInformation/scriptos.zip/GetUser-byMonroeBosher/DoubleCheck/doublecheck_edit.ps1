﻿[cmdletbinding()]
param (
[parameter(ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
[string[]]$ComputerName = $env:computername
)

$workstations = Get-Content "C:\Users\mb026392\Desktop\Scripts\computerlist_trainingroom.txt"
$report = @()
ForEach ($workstation in $workstations) {
  Try {
    $tempreport = New-Object PSObject
    $IP = ((Test-Connection -ea stop -Count 1 -comp $workstation).IPV4Address).IPAddresstoString
    $tempreport | Add-Member NoteProperty Workstation $workstation
    $tempreport | Add-Member NoteProperty Status "Up"
    $tempreport | Add-Member NoteProperty IP $ip
    $report += $tempreport
    } 
  Catch {
    $tempreport = New-Object PSObject
    $tempreport | Add-Member NoteProperty Workstation $workstation
    $tempreport | Add-Member NoteProperty Status "Down"
	$report += $tempreport
    }
  

if (Test-Connection -Computername $workstation -BufferSize 16 -Count 1) { 
$Profiles = Get-WmiObject -Class Win32_UserProfile -Computer $workstation -ea 0
 foreach ($profile in $profiles) {
  try {
	  $objSID = New-Object System.Security.Principal.SecurityIdentifier($profile.sid)
	  $objuser = $objsid.Translate([System.Security.Principal.NTAccount])
	  $objusername = $objuser.value
  } catch {
		$objusername = $profile.sid
  }
  switch($profile.status){
   1 { $profileType="Temporary" }
   2 { $profileType="Roaming" }
   4 { $profileType="Mandatory" }
   8 { $profileType="Corrupted" }
   default { $profileType = "LOCAL" }
  }
  $User = $objUser.Value
  $tempreport = Add-Member -MemberType NotePropery -Name User -Value $User  | Where-Object {$User -like "CORP*"}
  $tempreport | Add-Member -MemberType NoteProperty -Name ProfileName -Value $objusername
  $tempreport
  }
 }
}
$report | Export-Csv -NoTypeInformation "C:\Users\mb026392\Desktop\Scripts\online_report_test.csv"
