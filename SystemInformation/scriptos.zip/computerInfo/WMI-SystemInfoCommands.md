# Commands to Gather System Information using WMI queries.

Used to gather system information for inventory and reporting purposes.

```PowerShell

# Ping computer
$ping = gwmi Win32_PingStatus -filter "Address='$compname'"
if($ping.StatusCode -eq 0) { Write-Host "$compname is online." } else { Write-Host "$compname is offline" }

#PC Serial Number
gwmi -computer $compname Win32_BIOS | Select-Object SerialNumber | Format-List


#PC Printer Information
gwmi -computer $compname Win32_Printer | Select-Object DeviceID,DriverName, PortName | Format-List


#Current User
gwmi -computer $compname Win32_ComputerSystem | Format-Table @{Expression={$_.Username};Label="Current User"}
#May take a very long time if on a domain with many users
#"All Users"
#"------------"
#gwmi -computer $compname Win32_UserAccount | foreach{$_.Caption}


#OS Info
gwmi -computer $compname Win32_OperatingSystem | Format-List @{Expression={$_.Caption};Label="OS Name"},SerialNumber,OSArchitecture


#System Info
gwmi -computer $compname Win32_ComputerSystem | Format-List Name,Domain,Manufacturer,Model,SystemType


#Add/Remove Program List
gwmi -computer $compname Win32_Product | Sort-Object Name | Format-Table Name,Vendor,Version


#Process List
gwmi -computer $compname Win32_Process | Select-Object Caption,Handle | Sort-Object Caption | Format-Table


#Service List
gwmi -computer $compname Win32_Service | Select-Object Name,State,Status,StartMode,ProcessID, ExitCode | Sort-Object Name | Format-Table


#USB Devices
gwmi -computer $compname Win32_USBControllerDevice | %{[wmi]($_.Dependent)} | Select-Object Caption, Manufacturer, DeviceID | Format-List


#Uptime
$wmi = gwmi -computer $compname Win32_OperatingSystem
$localdatetime = $wmi.ConvertToDateTime($wmi.LocalDateTime)
$lastbootuptime = $wmi.ConvertToDateTime($wmi.LastBootUpTime)
"Current Time:      $localdatetime"
"Last Boot Up Time: $lastbootuptime"
$uptime = $localdatetime - $lastbootuptime
"Uptime: $uptime"


#Disk Info
$wmi = gwmi -computer $compname Win32_logicaldisk
foreach($device in $wmi){
    Write-Host "Drive: " $device.name
    Write-Host -NoNewLine "Size: "; "{0:N2}" -f ($device.Size/1Gb) + " Gb"
    Write-Host -NoNewLine "FreeSpace: "; "{0:N2}" -f ($device.FreeSpace/1Gb) + " Gb"
}


#Memory Info
$wmi = gwmi -computer $compname Win32_PhysicalMemory
foreach($device in $wmi){
    Write-Host "Bank Label:     " $device.BankLabel
    Write-Host "Capacity:       " ($device.Capacity/1MB) "Mb"
    Write-Host "Data Width:     " $device.DataWidth
    Write-Host "Device Locator: " $device.DeviceLocator
}


#Processor Info
gwmi -computer $compname Win32_Processor | Format-List Caption,Name,Manufacturer,ProcessorId,NumberOfCores,AddressWidth


#Monitor Info
#Turn off Error Messages
$ErrorActionPreference_Backup = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
$keytype=[Microsoft.Win32.RegistryHive]::LocalMachine
if($reg=[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($keytype,$compname)){
    #Create Table To Hold Info
    $montable = New-Object system.Data.DataTable "Monitor Info"
    #Create Columns for Table
    $moncol1 = New-Object system.Data.DataColumn Name,([string])
    $moncol2 = New-Object system.Data.DataColumn Serial,([string])
    $moncol3 = New-Object system.Data.DataColumn Ascii,([string])
    #Add Columns to Table
    $montable.columns.add($moncol1)
    $montable.columns.add($moncol2)
    $montable.columns.add($moncol3)
    $regKey= $reg.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\DISPLAY" )
    $HID = $regkey.GetSubKeyNames()
    foreach($HID_KEY_NAME in $HID){
        $regKey= $reg.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\\DISPLAY\\$HID_KEY_NAME" )
        $DID = $regkey.GetSubKeyNames()
        foreach($DID_KEY_NAME in $DID){
            $regKey= $reg.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\\DISPLAY\\$HID_KEY_NAME\\$DID_KEY_NAME\\Device Parameters" )
            $EDID = $regKey.GetValue("EDID")
            foreach($int in $EDID){
                $EDID_String = $EDID_String+([char]$int)
            }
            #Create new row in table
            $monrow=$montable.NewRow()
            #MonitorName
            $checkstring = [char]0x00 + [char]0x00 + [char]0x00 + [char]0xFC + [char]0x00
            $matchfound = $EDID_String -match "$checkstring([\w ]+)"
            if($matchfound){$monrow.Name = [string]$matches[1]} else {$monrow.Name = '-'}
            #Serial Number
            $checkstring = [char]0x00 + [char]0x00 + [char]0x00 + [char]0xFF + [char]0x00
            $matchfound =  $EDID_String -match "$checkstring(\S+)"
            if($matchfound){$monrow.Serial = [string]$matches[1]} else {$monrow.Serial = '-'}
            #AsciiString
            $checkstring = [char]0x00 + [char]0x00 + [char]0x00 + [char]0xFE + [char]0x00
            $matchfound = $EDID_String -match "$checkstring([\w ]+)"
            if($matchfound){$monrow.Ascii = [string]$matches[1]} else {$monrow.Ascii = '-'}
            $EDID_String = ''
            $montable.Rows.Add($monrow)
        }
    }
    $montable | select-object  -unique Serial,Name,Ascii | Where-Object {$_.Serial -ne "-"} | Format-Table
} else {
    Write-Host "Access Denied - Check Permissions"
}

```

### Enjoy! :)
