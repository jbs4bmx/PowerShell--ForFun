
Set-ExecutionPolicy -Bypass

$computerSystem = Get-CimInstance CIM_ComputerSystem
$computerBIOS = Get-CimInstance CIM_BIOSElement
$computerOS = Get-CimInstance CIM_OperatingSystem
$computerCPU = Get-CimInstance CIM_Processor
$computerHDD = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID = 'C:'"
Clear-Host

Out-File "C:\QorvoINFO.txt" "System Information for: " + $computerSystem.Name
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "Manufacturer: " + $computerSystem.Manufacturer
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "Model: " + $computerSystem.Model
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "Serial Number: " + $computerBIOS.SerialNumber
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "CPU: " + $computerCPU.Name
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "HDD Capacity: "  + "{0:N2}" -f ($computerHDD.Size/1GB) + "GB"
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "HDD Space: " + "{0:P2}" -f ($computerHDD.FreeSpace/$computerHDD.Size) + " Free (" + "{0:N2}" -f ($computerHDD.FreeSpace/1GB) + "GB)"
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "RAM: " + "{0:N2}" -f ($computerSystem.TotalPhysicalMemory/1GB) + "GB"
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "Operating System: " + $computerOS.caption + ", Service Pack: " + $computerOS.ServicePackMajorVersion
Add-Content C:\Qorvo_Setup\QorvoINFO.txt "User logged In: " + $computerSystem.UserName
"Last Reboot: " + $computerOS.LastBootUpTime >> C:\Qorvo_Setup\QorvoINFO.txt
