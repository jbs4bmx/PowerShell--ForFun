﻿<#
	This will show the status of WinRM on the machines listed in computerList.txt.
#>

$MYWINDOWSID=[SYSTEM.SECURITY.PRINCIPAL.WINDOWSIDENTITY]::GETCURRENT()
$MYWINDOWSPRINCIPAL=NEW-OBJECT SYSTEM.SECURITY.PRINCIPAL.WINDOWSPRINCIPAL($MYWINDOWSID)
$ADMINROLE=[SYSTEM.SECURITY.PRINCIPAL.WINDOWSBUILTINROLE]::ADMINISTRATOR
IF ($MYWINDOWSPRINCIPAL.ISINROLE($ADMINROLE)) {
		$HOST.UI.RAWUI.WINDOWTITLE = $MYINVOCATION.MYCOMMAND.DEFINITION + "(ELEVATED)"
		$HOST.UI.RAWUI.BACKGROUNDCOLOR = "DARKBLUE"
} ELSE {
	$NEWPROCESS = NEW-OBJECT SYSTEM.DIAGNOSTICS.PROCESSSTARTINFO "POWERSHELL";
	$NEWPROCESS.ARGUMENTS = $MYINVOCATION.MYCOMMAND.DEFINITION;
	$NEWPROCESS.VERB = "RUNAS";
	[SYSTEM.DIAGNOSTICS.PROCESS]::START($NEWPROCESS);
	EXIT
}

$SPAdmin = "GATE\ad009990"
$Password = cat C:\securestring.txt | ConvertTo-SecureString
$Cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $SPAdmin, $Password

foreach ( $Comp in (Get-Content "C:\computerList.txt")) {
	Get-WmiObject -Query "select * from win32_service where name='WinRM'" -ComputerName $Comp -Credential $Cred | Format-List -Property PSComputerName, Name, ExitCode, Name, ProcessID, StartMode, State, Status
}
Pause
exit 0
