﻿

	# Get the ID and security principal of the current user account
$MYWINDOWSID=[SYSTEM.SECURITY.PRINCIPAL.WINDOWSIDENTITY]::GETCURRENT()
$MYWINDOWSPRINCIPAL=NEW-OBJECT SYSTEM.SECURITY.PRINCIPAL.WINDOWSPRINCIPAL($MYWINDOWSID)
	# Get the security principal for the Administrator role
$ADMINROLE=[SYSTEM.SECURITY.PRINCIPAL.WINDOWSBUILTINROLE]::ADMINISTRATOR
	# Check to see if we are currently running "as Administrator"
IF ($MYWINDOWSPRINCIPAL.ISINROLE($ADMINROLE))
	{
			# We are running "as Administrator" - so change the title and background color to indicate this
		$HOST.UI.RAWUI.WINDOWTITLE = $MYINVOCATION.MYCOMMAND.DEFINITION + "(ELEVATED)"
		$HOST.UI.RAWUI.BACKGROUNDCOLOR = "DARKBLUE"
		CLEAR-HOST
	}
ELSE
	{
			# We are not running "as Administrator" - so relaunch as administrator
			# Create a new process object that starts PowerShell
		$NEWPROCESS = NEW-OBJECT SYSTEM.DIAGNOSTICS.PROCESSSTARTINFO "POWERSHELL";
			# Specify the current script path and name as a parameter
		$NEWPROCESS.ARGUMENTS = $MYINVOCATION.MYCOMMAND.DEFINITION;
			# Indicate that the process should be elevated
		$NEWPROCESS.VERB = "RUNAS";
			# Start the new process
		[SYSTEM.DIAGNOSTICS.PROCESS]::START($NEWPROCESS);
			# Exit from the current, unelevated, process
	EXIT
	}

	# Rest of the script that we need to execute follows here.

New-Item C:\test\bitsTest.log -type file
$Logfile = "C:\test\bitsTest.log"

Enable-PSRemoting -Force

Function LogWrite
{
    PARAM([string]$logstring)

    Add-Content $Logfile -Value $logstring
}

LogWrite ">+=======================================+"
LogWrite ">"
$TimeStamp = $(Get-Date –f o)
LogWrite "> $TimeStamp"
LogWrite ">"
LogWrite ">+=======================================+"

ForEach ($Remote in (Get-Content C:\test\COMPUTERLIST.TXT))
{
	Set-ExecutionPolicy Bypass -Force
	Enable-PSRemoting -Force
	
	Get-Service bits -ComputerName $Remote
	$status = Get-Service -Computer $Remote -Name bits | Where-Object {$_.status}
	
	If ($status -eq 'Running')
	{
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">System Name: $Remote"
		LogWrite ">Service Running!"
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">"
	}
	If ($status -eq 'Stopped')
	{
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">System Name: $Remote"
		LogWrite ">Service Stopped!"
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">"
	}
	Else
	{
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">System Name: $Remote"
		LogWrite ">Error or Service Not Found!"
		LogWrite ">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		LogWrite ">"
	}
}
LogWrite ">"

Pause
