$computers = Get-Content $computerList
foreach ($comp in $computers) {
    $pc = $comp
    Get-CimInstance -Class CIM_PhysicalMemory -ComputerName $pc -EA SilentlyContinue | Select-Object PSComputerName,DeviceLocator,Speed,Capacity,Manufacturer,Tag,PartNumber,SerialNumber | Format-Table | Out-File $output -Append
    Add-Content -FilePath $output -Value " "
}